# import basic packages
from glob import glob
from argparse import ArgumentParser
from textblob import TextBlob as tb
import os, sys, time, numpy as np

# import other useful packages
from VectorSpace import VectorSpace
from tfidf_np import *
from util import *

# global variable
DOC_DIR = "documents"
FILE_TYPE = "product"
TYEPS = [
        "Term Frequency (TF) Weighting + Cosine Similarity",
        "Term Frequency (TF) Weighting + Euclidean Distance",
        "TF-IDF Weighting + Cosine Similarity",
        "TF-IDF Weighting + Euclidean Distance"
        ]

def getArgs():
    parser = ArgumentParser('Project 1: Search and Rank via Vector Space Models.')
    parser.add_argument('--query', required=True, dest="query", help="Enter your Query.")
    parser.add_argument('--fb', action="store_true", help="Use it for feedback option")
    return parser.parse_args()

def getAllDoc(docPath):
    print("Start Processing...")
    start = time.time()
    all_doc = sorted(glob(docPath))
    print("Total document count: {}".format(len(all_doc)))
    # concate all documents
    # get vector space of all documents
    all_content, all_id = list(), list()
    for index, doc_name in enumerate(all_doc):
        all_id.append(os.path.splitext(os.path.basename(doc_name))[0])
        with open(doc_name) as doc :
            all_content.append(doc.readlines()[0])
    doc_count = len(all_content)
    return all_content, all_id, doc_count, start

def getVSM(all_content):
    vectorSpace = VectorSpace(all_content)
    
    # assert document vector not none
    # assert the count of all content we append are as same as vectorSpace's documentVectors
    assert len(vectorSpace.documentVectors) >= 1
    assert doc_count == len(vectorSpace.documentVectors)
    tfVector = np.zeros((doc_count, len(vectorSpace.documentVectors[0])),np.float64)
    docVector = np.asarray(vectorSpace.documentVectors)
    keyWordIndex = vectorSpace.vectorKeywordIndex
    docTbVectorIndex = list()
    return tfVector, docVector, docTbVectorIndex, keyWordIndex

def getTfVector(all_content, keyWordIndex, tfVector, docTbVectorIndex): 
    for idx, each_doc in enumerate(all_content) :
        
        # get all info to calculate tf
        eachDocTb = tb(each_doc).words
        eachDocVector = docVector[idx]
        eachTbVectorIndex = [word for word in eachDocTb if word in keyWordIndex.keys()]
        tfVector[idx] = tf(eachDocVector, eachTbVectorIndex)
        docTbVectorIndex.append(eachTbVectorIndex)
    return tfVector, docTbVectorIndex

def getIdfVector(doc_count, docVector, docTbVectorIndex, all_content):
    idfVector = np.zeros((doc_count, len(docVector[0])), np.float64)
    assert doc_count == len(docTbVectorIndex)
    for idx, each_doc in enumerate(all_content) :
        eachDocTbInedx = docTbVectorIndex[idx]
        idfVector[idx] = idf(eachDocTbInedx, docTbVectorIndex)
    return idfVector

def get_final_vector(tfVector, idfVector, queryVector):
    final_query_tf = np.einsum('ij, ij->ij', tfVector, queryVector)
    final_query_tfidf = np.einsum('ij, ij->ij', final_query_tf, idfVector)
    return tfVector, idfVector, final_query_tf, final_query_tfidf

def checkFeedBack(feedback, tfVector, idfVector):
    if feedback :
        pass
    else:
        finalWeightTFIDF = np.einsum('ij, ij->ij', tfVector, idfVector)
        finalWeightTF = tfVector
    return finalWeightTF, finalWeightTFIDF

def getQueryVector(query, keyWordIndex):
    query = "drill wood sharp"
    queryVector = np.zeros((1,len(keyWordIndex)),np.float64)
    for word in tb(query).words :
        if word in keyWordIndex.keys():
            queryVector[0,keyWordIndex[word]] = 1
    return queryVector

def getAllDistance(final_query_tf, final_query_tfidf, finalWeightTF, finalWeightTFIDF, doc_count):
    allDistance = list()
    allDistance.append(cosine(finalWeightTF, final_query_tf))
    allDistance.append(euclideanDist(finalWeightTF, final_query_tf))
    allDistance.append(cosine(finalWeightTFIDF, final_query_tfidf))
    allDistance.append(euclideanDist(finalWeightTFIDF, final_query_tfidf))
    return allDistance

if __name__ == "__main__":
    
    args = getArgs()
    query = args.query
    feedback = args.fb
    docPath = os.path.join(DOC_DIR, "*"+FILE_TYPE)
    print("Using Query: {}".format(query))
    print("Processing: {}".format(docPath))
    print("====================================")
    
    # get all docs
    all_content, all_id, doc_count, start = getAllDoc(docPath)
    
    # get vectorspace mode and its data
    tfVector, docVector, docTbVectorIndex, keyWordIndex = getVSM(all_content)

    # get tf vector
    tfVector, docTbVectorIndex = getTfVector(all_content, keyWordIndex, tfVector, docTbVectorIndex)
    
    # count each doc's idf
    idfVector = getIdfVector(doc_count, docVector, docTbVectorIndex, all_content)
    
    # calculate for final weight
    # finalWeightTF, finalWeightTFIDF = checkFeedBack(feedback, tfVector, idfVector)

    # here for query indexing
    queryVector = getQueryVector(query, keyWordIndex)
    
    # get final query and weighting
    finalWeightTF, finalWeightTFIDF, final_query_tf, final_query_tfidf = get_final_vector(tfVector, idfVector, queryVector)
    
    # calculate distance
    allDistance = getAllDistance(final_query_tf, final_query_tfidf, finalWeightTF, finalWeightTFIDF, doc_count)
    
    for idx, eachDst in enumerate(allDistance):

        mappedResult = dict(zip(list(all_id), list(eachDst)))
        
        if idx%2 == 0 :
            finalResult = {k: v for k, v in sorted(mappedResult.items(), key=lambda item:item[1], reverse=True)}
        else :
            finalResult = {k: v for k, v in sorted(mappedResult.items(), key=lambda item:item[1], reverse=False)}
        
        print("DocID    Score   {}".format(TYEPS[idx]))
        for result_idx, (key, value) in enumerate(finalResult.items()) :
            if result_idx == 5 :
                break
            print("{}   {}   ".format(key, round(value, 6)))

        print("=======================")
    
    # retrieve spending time
    end = time.time()
    print(round(end - start, 2), "Seconds")
