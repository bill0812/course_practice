import sys, os
import numpy as np

def removeDuplicates(list):
    """ remove duplicates from a list """
    return set((item for item in list))

def cosine(vector1, vector2):
    """ cosine  = ( V1 * V2 ) / ||V1|| x ||V2|| """
    # for each document vectors and its corresponding query vector which are all
    # the same among all doc vectors, we use 'einsum' operation to get the value, which is a sort of
    # matrix operation collection including dot operation
    return np.einsum('ij,ij->i', vector1, vector2) / (np.apply_along_axis(np.linalg.norm, 1, vector1) * np.apply_along_axis(np.linalg.norm, 1, vector2))

def euclideanDist(vector1, vector2):

    return np.apply_along_axis(np.linalg.norm, 1, vector1-vector2)

def dir_path(input_string):
    if os.path.isdir(input_string):
        return input_string
    else:
        raise NotADirectoryError(input_string)
